import "./index.scss"
import PendingPayments from "../../components/pendingpayments";
function Cashless(props) {



    return (
        <div className={"Cashless page-container"}>
            <PendingPayments/>
        </div>


    )

}





export default Cashless;